var express = require("express");
var router = express.Router();
var indexController = require("../controllers/indexController");
var swaggerController = require("../swagger/swagger");
var util = require("../controllers/utilController");

/* GET Swagger page. */
router.get("/api-docs", swaggerController.docs);
router.get("/swagger", swaggerController.swagger);

router.post("/auth", indexController.auth);
router.post("/verify", util.authUser, indexController.verify);

module.exports = router;
