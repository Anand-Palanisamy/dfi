var express = require("express");
var router = express.Router();
var customerController = require("../controllers/customerController");
var util = require("../controllers/utilController");

/* GET home page. */
router.get("/searchcustomer/:key?", util.authUser, customerController.search);
router.get("/getcustomers", util.authUser, customerController.getCustomers);
router.post("/createcustomer", util.authUser, customerController.addCustomer);
router.delete("/deletecustomer/:_id", util.authUser, customerController.deleteCustomer);

//for get customer and particular customers loans details
router.get("/getcustomer-lists", util.authUser, customerController.getCustomersLists);
router.patch("/updatecustomer", util.authUser, customerController.updateCustomer);

router.get("/getmaster-voucherbook", util.authUser, customerController.getMasterVoucherBook);

//for get customer profile with customer details and particular customers loan and loan history details
router.post("/getcustomer-profile", util.authUser, customerController.getCustomerProfile);

router.get("/receipt", util.authUser, customerController.receipt);

module.exports = router;
