var express = require("express");
var router = express.Router();
var loanController = require("../controllers/loanController");
var eodController = require("../controllers/eodController")
var util = require("../controllers/utilController");

/* GET home page. */
router.get("/search/:key?", util.authUser, loanController.search);
router.get("/getloans", util.authUser, loanController.getLoans);
router.post("/createloan", util.authUser, loanController.addLoan);
// router.post("/updateloan", util.authUser, loanController.updateLoan);
router.delete("/deleteloan/:_id", util.authUser, loanController.deleteLoan);

/* Daily Collections */
router.post("/getdailycollections", util.authUser, loanController.getDailyCollections);
router.post("/adddailycollection", util.authUser, loanController.addDailyCollection);

/* Monthly Collections */
router.post("/getmonthlyloans", util.authUser, loanController.getMonthlyCollections);
router.post("/addmonthlyloan", util.authUser, loanController.addMonthlyCollection);

/* Loan Ledgers */
router.post("/getmonthlyloan-ledger", util.authUser, loanController.getMonthlyLoanLedger);
router.post("/getdailyloan-ledger", util.authUser, loanController.getDailyLoanLedger);


//eod update
router.get("/geteod", util.authUser, eodController.getEOD);
router.post("/addeod", util.authUser, eodController.addEOD);


// expense
router.get("/getexpense", util.authUser, eodController.getExpense);
router.post("/addexpense", util.authUser, eodController.addExpense);


module.exports = router;
