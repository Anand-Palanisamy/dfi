var monthlyCollectionSchema = {
  updated_by: String,
  created_by: String,
  status: String,
  updated_at: { type: Date, default: Date.now },
  created_at: { type: Date, default: Date.now },
  loan_id: {
    type: String,
    required: true,
  },
  date: {
    type: Date,
    required: true,
  },
  month: {
    type: String,
    required: true,
  },
  interest_amount: {
    type: Number,
    required: false,
  },
  capital: {
    type: Number,
    required: true,
  },
  balance: {
    type: Number,
    required: false,
  },
  paid_amount: {
    type: Number,
    required: false,
  },
  collected_by: {
    type: String,
    required: true,
  },
};

var monthlyCollection_data = {};
monthlyCollection_data.monthlyCollectionSchema = monthlyCollectionSchema;
module.exports = monthlyCollection_data;
