var dailyCollectionSchema = {
  updated_by: String,
  created_by: String,
  status: String,
  updated_at: { type: Date, default: Date.now },
  created_at: { type: Date, default: Date.now },
  loan_id: {
    type: String,
    required: true,
  },
  due_date: {
    type: Date,
    required: true,
  },
  installment: {
    type: Number,
    required: true,
  },
  due_paying_amount: {
    type: Number,
    required: true,
  },
  balance_amount: {
    type: Number,
    required: false,
  },
  total_paid_amount: {
    type: Number,
    required: true,
  },
  to_be_collect: {
    type: Number,
    required: true,
  },
  collected_by: {
    type: String,
    required: true,
  },
};

var dailyCollection_data = {};
dailyCollection_data.dailyCollectionSchema = dailyCollectionSchema;
module.exports = dailyCollection_data;
