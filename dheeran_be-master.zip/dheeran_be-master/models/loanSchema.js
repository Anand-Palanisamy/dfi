var loanSchema = {
  updated_by: String,
  created_by: String,
  status: String,
  updated_at: { type: Date, default: Date.now },
  created_at: { type: Date, default: Date.now },
  cust_id: {
    type: String,
    required: true,
  },
  loan_type: {
    type: String,
    required: true,
  },
  loan_no: {
    type: Number,
    required: true,
    unique: true,
  },
  loan_date: {
    type: Date,
  },
  voucher_no: {
    type: Number,
    required: true,
    unique: true,
  },
  amount: {
    type: Number,
    required: true,
  },
  interest: {
    type: Number,
    required: false,
  },
  duration: {
    type: String,
    require: true,
  },
  daily_amount: {
    type: Number,
    required: false,
  },
};

var loandata = {};
loandata.loanSchema = loanSchema;
module.exports = loandata;
