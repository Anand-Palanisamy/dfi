var eodUpdateSchema = {
  updated_by: String,
  created_by: String,
  status: String,
  updated_at: { type: Date, default: Date.now },
  created_at: { type: Date, default: Date.now },
  interest: {
    type: Number,
    required: true,
  },
  chit_collection: {
    type: Number,
    required: true,
  },
  ifc_daily: {
    type: Number,
    required: true,
  },
};

var eoddata = {};
eoddata.eodUpdateSchema = eodUpdateSchema;

module.exports = eoddata