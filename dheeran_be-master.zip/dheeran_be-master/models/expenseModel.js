// Expense Schema
var expenseSchema = {
  updated_by: String,
  created_by: String,
  status: String,
  updated_at: { type: Date, default: Date.now },
  created_at: { type: Date, default: Date.now },
  particular: {
    type: String,
    required: true,
  },
  capital_return: {
    type: String,
    required: false,
  },
  interest: {
    type: String,
    required: false,
  },
  amount: {
    type: Number,
    required: true,
  },
  date: {
    type: Date,
    required: true,
  },
};

var expensedata = {};
expensedata.expenseSchema = expenseSchema;

module.exports = expensedata;
