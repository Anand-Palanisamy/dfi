var customerSchema = {
  updated_by: String,
  created_by: String,
  status: String,
  updated_at: { type: Date, default: Date.now },
  created_at: { type: Date, default: Date.now },
  customer_name: {
    type: String,
    required: true,
  },
  customer_id: {
    type: Number,
    required: true,
    unique: true,
  },
  phone_number: {
    type: Number,
    trim: true,
    validate: {
      validator: function (v) {
        return /^[0-9]{10}/.test(v);
      },
      message: '{VALUE} is not a valid 10 digit number!'
    }
  },
  address: {
    type: String,
    required: true,
  },
  business: {
    type: String,
    required: false,
  },
};

var customerdata = {};
customerdata.customerSchema = customerSchema;
module.exports = customerdata;
