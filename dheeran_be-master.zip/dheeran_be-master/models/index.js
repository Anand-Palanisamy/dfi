//Models
var mongoose = require("mongoose");
var customerschema = require("./customerSchema");
var loanschema = require("./loanSchema");
var dailyCollectionschema = require("./dailycollectionSchemas");
var monthlyCollectionschema = require("./monthlycollectionSchema");
var eodUpdateschema = require("./eodModel")
var expenseschema = require("./expenseModel")

var constants = require("../config/constants");
// var connection = mongoose.connect(constants.app.db);
// console.log('process.env.DB_NAME', process.env.DB_NAME)
// console.log('process.env.DB_USER', process.env.DB_USER)
// console.log('process.env.DB_PASS', process.env.DB_PASS)
mongoose
  .connect(process.env.MONGODB_URI, {
    dbName: process.env.DB_NAME,
    user: process.env.DB_USER,
    pass: process.env.DB_PASS,
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log("Mongodb connected....");
  })
  .catch((err) => console.log(err.message));

var Schema = mongoose.Schema;

// Defining schema
var customerSchema = customerschema.customerSchema;
var loanSchema = loanschema.loanSchema;
var dailyCollectionSchema = dailyCollectionschema.dailyCollectionSchema;
var monthlyCollectionSchema = monthlyCollectionschema.monthlyCollectionSchema;
var eodUpdateSchema = eodUpdateschema.eodUpdateSchema;
var expenseSchema = expenseschema.expenseSchema

//Defining schema to variable
var customer = mongoose.model("customer", customerSchema);
var loan = mongoose.model("loan", loanSchema);
var daily_collection = mongoose.model(
  "daily_collection",
  dailyCollectionSchema
);
var monthly_collection = mongoose.model(
  "monthly_collection",
  monthlyCollectionSchema
);
var eod_update = mongoose.model("eod_update", eodUpdateSchema);
var expense = mongoose.model("expense", expenseSchema);

//Debug mode
mongoose.set("debug", true);

//Exporting Schema
module.exports = {
  customer,
  loan,
  daily_collection,
  monthly_collection,
  expense,
  eod_update
};
