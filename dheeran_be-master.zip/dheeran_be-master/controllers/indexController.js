var constants = require("../config/constants");
var util = require("./utilController");
var jwt = require("jsonwebtoken");

exports.auth = function (req, res) {
  var token = util.generateToken();
  token = jwt.sign({ sa: token }, constants.getTxt().JWT_SECRET);
  res.status(200).json({ message: token });
};

exports.verify = function (req, res) {
  var token = util.generateToken();
  token = jwt.sign({ sa: token }, constants.getTxt().JWT_SECRET, {
    expiresIn: "24h",
  });
  res.status(200).json({ message: "Success" });
};
