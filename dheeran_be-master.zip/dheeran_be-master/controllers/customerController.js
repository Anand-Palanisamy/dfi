var constants = require("../config/constants");
var dbModel = require("../models/index");
const _ = require("underscore");

exports.search = async function (req, res, next) {
  try {
    var param = req.params.key;
    if (param == undefined) {
      var data = await dbModel.customer.find({});
    } else {
      var data = await dbModel.customer.find({
        $or: [
          {
            customer_name: {
              $regex: param,
              $options: "i",
            },
          },
          {
            customer_id: {
              $regex: param,
              $options: "i",
            },
          },
        ],
      });
    }

    res.send(data);
  } catch (error) {
    console.log(error.message);
  }
};

exports.getCustomers = async function (req, res) {
  try {
    var data = await dbModel.customer.find({},{
      updated_at: 0,
      created_at: 0,
      __v: 0
    });
    res.json({ data: data });
  } catch (error) {
    res.json({
      message: constants.messages.general.error,
      error: error,
    });
  }
};

exports.addCustomer = async function (req, res, next) {
  try {
    var data = new dbModel.customer(req.body);
    var savedData = await data.save();
    res.status(200).json({
      success: true,
      message: constants.messages.general.create_success,
      data: savedData,
    });
  } catch (error) {
    // console.log(error.message);
    res.status(422).json({
      error: (error.message),
      message: constants.messages.general.cust_not_created
    });
    next(error);
  }
};

exports.updateCustomer = async function (req, res, next) {
  try {
    var whereQuery = { _id: req.body._id };
    try {
      const data = await dbModel.customer.findOne(whereQuery);
      console.log(data);
      if (data == null) {
        res.status(404).json({
          success: false,
          message: constants.messages.general.no_data,
        });
      } else {
        var updateData = req.body;
        const options = {
          new: true,
        };
        const savedData = await dbModel.customer.findByIdAndUpdate(
          req.body._id,
          updateData,
          options
        );
        res.status(200).json({
          success: true,
          message: constants.messages.general.update_success,
          data: savedData,
        });
      }
    } catch (error) {
      console.log("error", error);
      res.status(500).json({
        success: false,
        message: constants.messages.general.server_error,
        data: {
          error: error,
        },
      });
    }
  } catch (error) {
    console.log("error", error);
    res.status(500).json({
      success: false,
      message: constants.messages.general.server_error,
      data: {
        error: error,
      },
    });
  }
};

exports.deleteCustomer = async function (req, res, next) {
  try {
    var whereQuery = { _id: req.params._id };
    try {
      const data = await dbModel.customer.findOne(whereQuery);
      console.log(data);
      if (data == null) {
        res.status(404).json({
          success: false,
          message: constants.messages.general.no_data,
        });
      } else {
        const result = await dbModel.customer.findByIdAndDelete(req.params._id);
        res.status(200).json({
          success: true,
          message: constants.messages.general.delete_success,
        });
      }
    } catch (error) {
      console.log("error", error);
      res.status(500).json({
        success: false,
        message: constants.messages.general.server_error,
        data: {
          error: error,
        },
      });
    }
  } catch (error) {
    console.log("error", error);
    res.status(500).json({
      success: false,
      message: constants.messages.general.server_error,
      data: {
        error: error,
      },
    });
  }
};

exports.getCustomersLists = async function (req, res, next) {
  try {
    const customer = await dbModel.customer.find(
      {},
      {
        customer_id: 1,
        phone_number: 1,
        customer_name: 1,
        address: 1,
        business: 1,
      }
    );

    const loan = await dbModel.loan.find(
      {},
      {
        cust_id: 1,
        voucher_no: 1,
        loan_no: 1,
        loan_type: 1,
      }
    );

    var customerArray = [];

    for (let index = 0; index < loan.length; index++) {
      var loan_element = loan[index];

      // console.log("loan_element.customer_id -------->", loan_element);

      var foundCustomer = _.findWhere(customer, {
        id: loan_element.cust_id,
      });

      // console.log("foundCustomer is  -------->", foundCustomer);

      if (foundCustomer == undefined) {
        var outputObject = {
          message: "Customer or Loan details not found ",
        };

        customerArray.push(outputObject);
      } else {
        var outputObject = {
          cust_id: foundCustomer._id,
          loan_id: loan_element._id,
          customer_id: foundCustomer.customer_id,
          phone_number: foundCustomer.phone_number,
          customer_name: foundCustomer.customer_name,
          address: foundCustomer.address,
          //business: foundCustomer.business,
          voucher_no: loan_element.voucher_no,
          loan_no: loan_element.voucher_no,
          loan_type: loan_element.loan_type,
        };

        customerArray.push(outputObject);
      }
    }
    //console.log("customer details ----------------->", customerArray);
    res.send(customerArray);
  } catch (error) {
    console.log(error.message);
  }
};


exports.getMasterVoucherBook = async function (req, res, next) {
  try {
    const customer = await dbModel.customer.find(
      {},
      {
        customer_name: 1,
      }
    );
    const loan = await dbModel.loan.find(
      {},
      {
        cust_id: 1,
        voucher_no: 1,
        loan_no: 1,
        loan_date: 1,
        loan_type: 1,
        amount: 1,
      }
    );

    var masterVoucherBookArray = [];

    for (let index = 0; index < loan.length; index++) {
      var loan_element = loan[index];

      //console.log("loan_element is -------->", loan_element);

      var foundCustomer = _.findWhere(customer, {
        id: loan_element.cust_id,
      });

      //console.log("foundCustomer is -------->", foundCustomer);
      if (foundCustomer == undefined) {
        var outputObject = {
          message: "Customer or Loan details not found ",
        };

        masterVoucherBookArray.push(outputObject);
      } else {
        var outputObject = {
          cust_id: foundCustomer._id,
          loan_id: loan_element._id,
          customer_name: foundCustomer.customer_name,
          voucher_no: loan_element.voucher_no,
          loan_no: loan_element.voucher_no,
          loan_date: loan_element.loan_date,
          loan_type: loan_element.loan_type,
          amount: loan_element.amount,
        };

        masterVoucherBookArray.push(outputObject);
      }
    }

    res.send(masterVoucherBookArray);
  } catch (error) {
    console.log(error.message);
  }
};

exports.getCustomerProfile = async function (req, res, next) {
  try {
    var arr = [];
    const customer = await dbModel.customer.findOne(
      {
        _id: req.body.cust_id,
      },
      {
        customer_name: 1,
        customer_id: 1,
        phone_number: 1,
        address: 1,
        business: 1,
      }
    );

    const loan = await dbModel.loan.findOne(
      {
        _id: req.body.loan_id,
      },
      {
        amount: 1,
        loan_no: 1,
        loan_type: 1,
      }
    );

    const daily_loan = await dbModel.daily_collection
      .findOne(
        {
          loan_id: req.body.loan_id,
        },
        {
          balance_amount: 1,
          total_paid_amount: 1,
        }
      )
      .sort({
        $natural: -1,
      });

    const monthly_loan = await dbModel.monthly_collection
      .findOne(
        {
          loan_id: req.body.loan_id,
        },
        {
          balance: 1,
          paid_amount: 1,
        }
      )
      .sort({
        $natural: -1,
      });

    if (daily_loan == null) {
      {
        var outputObject = {
          customer_name: customer.customer_name,
          customer_id: customer.customer_id,
          phone_number: customer.phone_number,
          address: customer.address,
          business: customer.business,
          loan_no: loan.loan_no,
          loan_type: loan.loan_type,
          amount: loan.amount,
          pending_amount: monthly_loan.balance,
          paid_amount: monthly_loan.paid_amount,
          status: "",
        };
        arr.push(outputObject);
      }
    } else {
      {
        var outputObject = {
          customer_name: customer.customer_name,
          customer_id: customer.customer_id,
          phone_number: customer.phone_number,
          address: customer.address,
          business: customer.business,
          loan_no: loan.loan_no,
          loan_type: loan.loan_type,
          amount: loan.amount,
          pending_amount: daily_loan.balance_amount,
          paid_amount: daily_loan.total_paid_amount,
          status: "",
        };

        arr.push(outputObject);
      }
    }

    res.send(arr);
  } catch (error) {
    console.log(error.message);
  }
};

exports.receipt = async function (req, res, next) {
  try {
    var arr = [];
    const customer = await dbModel.customer.find(
      {},
      {
        _id: 1,
        customer_name: 1,
      }
    );

    // console.log("customer ------ >", customer)

    const loan = await dbModel.loan.find(
      {
        // loan_type: req.body.loan_type,
      },
      {
        cust_id: 1,
        loan_date: 1,
        amount: 1,
        loan_no: 1,
      }
    );
    // console.log("loan ------ >", loan)

    const daily_collection = await dbModel.daily_collection
      .find(
        {},
        {
          loan_id: 1,
          total_paid_amount: 1,
        }
      )
      .sort({ _id: -1 });

    // console.log("daily_collection ------ >", daily_collection)

    const monthly_collection = await dbModel.monthly_collection
      .find(
        {},
        {
          loan_id: 1,
          paid_amount: 1,
        }
      )
      .sort({ _id: -1 });

    // console.log("monthly_collection ------ >", monthly_collection)

    for (let index = 0; index < loan.length; index++) {
      const loan_element = loan[index];

      // console.log("loan_element -------->",loan_element)

      var foundCustomer = _.findWhere(customer, {
        id: loan_element.cust_id,
      });

      var foundDailyLoan = _.findWhere(daily_collection, {
        loan_id: loan_element.id,
      });

      var foundMonthlyLoan = _.findWhere(monthly_collection, {
        loan_id: loan_element.id,
      });

      // console.log("foundCustomer -------->",foundCustomer)

      // console.log("foundDailyLoan -------->", foundDailyLoan);

      console.log("foundMonthlyLoan -------->",foundMonthlyLoan)

      if (foundDailyLoan != undefined) {
        var outputObject = {
          loan_no: loan_element.loan_no,
          date: loan_element.loan_date,
          customer_name: foundCustomer.customer_name,
          amount: loan_element.amount,
          paid: foundDailyLoan.total_paid_amount
        };
        arr.push(outputObject);
      } else {
        var outputObject = {
          loan_no: loan_element.loan_no,
          date: loan_element.loan_date,
          customer_name: foundCustomer.customer_name,
          amount: loan_element.amount,
          paid: 0
        };
        arr.push(outputObject);
      }
    }

    res.send(arr);
  } catch (error) {
    console.log(error.message);
  }
};