var authUser = [jwtCheck];
var jwt = require("jsonwebtoken");
var constants = require("../config/constants");

generateToken = function () {
  return Math.random().toString(36).slice(2);
};

function jwtCheck(req, res, next) {
  // var cookies = new Cookies(req, res, {
  //     keys: constants.getTxt().COOKIE_SECRET
  // });
  // var token = cookies.get('saCookie', {
  //         signed: true
  //     })
  // console.log(cookies);
  // console.log("Request with token ");
  // console.log(JSON.stringify(req.headers));
  // console.log(req.headers.authorization);
  if (
    req.headers.authorization == undefined ||
    req.headers.authorization == ""
  ) {
    res.status(401).json({ message: "Auth Token Missing" });
  } else {
    var token = req.headers.authorization;
    jwt.verify(token, constants.getTxt().JWT_SECRET, function (err, decoded) {
      if (err) {
        res.status(401).json({ message: "Invalid Auth Code" });
      } else {
        next();
      }
    });
  }
}

var util = {};
util.authUser = authUser;
util.generateToken = generateToken;
module.exports = util;
