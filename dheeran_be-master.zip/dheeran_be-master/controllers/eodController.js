var constants = require("../config/constants");
var dbModel = require("../models/index");
const _ = require("underscore");

exports.getEOD = async function (req, res) {
  try {
    var data = await dbModel.eod_update.find({});
    res.json({ data: data });
  } catch (error) {
    res.json({
      message: constants.messages.general.error,
      error: error,
    });
  }
};

exports.addEOD = async function (req, res) {
  try {
    var data = new dbModel.eod_update(req.body);
    var savedData = await data.save();
    res.status(200).json({
      success: true,
      message: constants.messages.general.create_success,
      data: savedData,
    });
  } catch (error) {
    //console.log("error", error);
    res.status(422).json({
      success: false,
      message: constants.messages.general.validation_error,
      data: {
        error: error,
      },
    });
  }
};

exports.getExpense = async function (req, res) {
    try {
      var data = await dbModel.expense.find({});
      res.json({ data: data });
    } catch (error) {
      res.json({
        message: constants.messages.general.error,
        error: error,
      });
    }
  };
  
  exports.addExpense = async function (req, res) {
    try {
      var data = new dbModel.expense(req.body);
      var savedData = await data.save();
      res.status(200).json({
        success: true,
        message: constants.messages.general.create_success,
        data: savedData,
      });
    } catch (error) {
      //console.log("error", error);
      res.status(422).json({
        success: false,
        message: constants.messages.general.validation_error,
        data: {
          error: error,
        },
      });
    }
  };

// exports.updateEOD = async function (req, res) {
//   try {
//     var whereQuery = { _id: req.body._id };
//     try {
//       const data = await dbModel.eod_update.findOne(whereQuery);
//       console.log(data);
//       if (data == null) {
//         res.status(404).json({
//           success: false,
//           message: constants.messages.general.no_data,
//         });
//       } else {
//         var updateData = req.body;
//         const options = {
//           new: true,
//         };
//         const savedData = await dbModel.eod_update.findByIdAndUpdate(
//           req.body._id,
//           updateData,
//           options
//         );
//         res.status(200).json({
//           success: true,
//           message: constants.messages.general.update_success,
//           data: savedData,
//         });
//       }
//     } catch (error) {
//       console.log("error", error);
//       res.status(500).json({
//         success: false,
//         message: constants.messages.general.server_error,
//         data: {
//           error: error,
//         },
//       });
//     }
//   } catch (error) {
//     console.log("error", error);
//     res.status(500).json({
//       success: false,
//       message: constants.messages.general.server_error,
//       data: {
//         error: error,
//       },
//     });
//   }
// };

// exports.deleteEOD = async function (req, res) {
//   try {
//     var whereQuery = { _id: req.params._id };
//     try {
//       const data = await dbModel.eod_update.findOne(whereQuery);
//       console.log(data);
//       if (data == null) {
//         res.status(404).json({
//           success: false,
//           message: constants.messages.general.no_data,
//         });
//       } else {
//         const result = await dbModel.eod_update.findByIdAndDelete(req.params._id);
//         res.status(200).json({
//           success: true,
//           message: constants.messages.general.delete_success,
//         });
//       }
//     } catch (error) {
//       console.log("error", error);
//       res.status(500).json({
//         success: false,
//         message: constants.messages.general.server_error,
//         data: {
//           error: error,
//         },
//       });
//     }
//   } catch (error) {
//     console.log("error", error);
//     res.status(500).json({
//       success: false,
//       message: constants.messages.general.server_error,
//       data: {
//         error: error,
//       },
//     });
//   }
// };
