var constants = require("../config/constants");
var dbModel = require("../models/index");
const _ = require("underscore");

exports.search = async function (req, res, next) {
  try {
    var param = req.params.key;
    if (param == undefined) {
      var data = await dbModel.loan.find({});
    } else {
      var data = await dbModel.loan.find({
        $or: [
          {
            loan_type: {
              $regex: param,
              $options: "i",
            },
          },
          {
            loan_no: {
              $regex: param,
              $options: "i",
            },
          },
          {
            loan_date: {
              $regex: param,
              $options: "i",
            },
          },
          {
            voucher_no: {
              $regex: param,
              $options: "i",
            },
          },
        ],
      });
    }
    res.send(data);
  } catch (error) {
    console.log(error.message);
  }
};

exports.getLoans = async function (req, res, next) {
  try {
    var data = await dbModel.loan.find({},{
      updated_at: 0,
      created_at: 0,
      __v: 0
    });
    res.json({ data: data });
  } catch (error) {
    res.json({
      message: constants.messages.general.error,
      error: error,
    });
  }
};

exports.addLoan = async function (req, res, next) {
  try {
    var data = new dbModel.loan(req.body);

    if (data.loan_type == "DAILY COLLECTION") {
      data.interest = data.amount / process.env.DAILY_INTEREST;

      // res.send(data);
      var savedData = await data.save();
      res.status(200).json({
        success: true,
        message: constants.messages.general.create_success,
        data: savedData,
      });
    } else if (data.loan_type == "DAILY COLLECTIONS") {
      data.interest = data.amount / process.env.DAILY_INTEREST;

      // res.send(data);
      var savedData = await data.save();
      res.status(200).json({
        success: true,
        message: constants.messages.general.create_success,
        data: savedData,
      });
    } else {
      data.interest = data.amount * process.env.MONTHLY_INTEREST;
      // res.send(data);

      var savedData = await data.save();
      res.status(200).json({
        success: true,
        message: constants.messages.general.create_success,
        data: savedData,
      });
    }
  } catch (error) {
    res.status(422).json({
      error: (error.message),
      message: constants.messages.general.loan_not_created
    });
    next(error);
  }
};

exports.deleteLoan = async function (req, res, next) {
  try {
    var whereQuery = { _id: req.params._id };
    try {
      const data = await dbModel.loan.findOne(whereQuery);
      console.log(data);
      if (data == null) {
        res.status(404).json({
          success: false,
          message: constants.messages.general.no_data,
        });
      } else {
        const result = await dbModel.loan.findByIdAndDelete(req.params._id);
        res.status(200).json({
          success: true,
          message: constants.messages.general.delete_success,
        });
      }
    } catch (error) {
      console.log("error", error);
      res.status(500).json({
        success: false,
        message: constants.messages.general.server_error,
        data: {
          error: error,
        },
      });
    }
  } catch (error) {
    console.log("error", error);
    res.status(500).json({
      success: false,
      message: constants.messages.general.server_error,
      data: {
        error: error,
      },
    });
  }
};

exports.getDailyCollections = async function (req, res, next) {
  try {
    var data = await dbModel.daily_collection.find(
      {
        loan_id: req.body.loan_id,
      },
      {
        _id: 0,
        due_date: 1,
        installment: 1,
        due_paying_amount: 1,
        balance_amount: 1,
        total_paid_amount: 1,
        to_be_collect: 1,
        collected_by: 1,
      }
    );

    res.json({ data: data });
  } catch (error) {
    res.json({
      message: constants.messages.general.error,
      error: error,
    });
  }
};

exports.addDailyCollection = async function (req, res, next) {
  try {
    const loan = await dbModel.loan.findOne(
      {
        _id: req.body.loan_id,
      },
      {
        _id: 0,
        amount: 1,
      }
    );

    var dailyArr = [];
    const dailyLoan = new dbModel.daily_collection(req.body);

    if (dailyLoan.installment == "1") {
      dailyLoan.balance_amount = loan.amount - dailyLoan.due_paying_amount ;

      dailyLoan.total_paid_amount =
        dailyLoan.total_paid_amount + dailyLoan.due_paying_amount;

      dailyLoan.to_be_collect =
        dailyLoan.due_paying_amount + dailyLoan.to_be_collect;

      const savedData = await dailyLoan.save();

      dailyArr.push(savedData);
    } else {
      const daily_collection = await dbModel.daily_collection.find(
        {
          loan_id: req.body.loan_id,
        },
        {
          due_paying_amount: 1,
          total_paid_amount: 1,
          due_paying_amount: 1,
          to_be_collect: 1,
          balance_amount: 1,
        }
      );
      const dailyLoan = new dbModel.daily_collection(req.body);

      console.log("dailyLoan ------->", dailyLoan);

      for (let index = 0; index < daily_collection.length; index++) {
        const daily_collection_element = daily_collection[index];

        console.log(
          "daily_collection_element ------->",
          daily_collection_element
        );

        console.log(
          "daily_collection_element balance_amount ------->",
          daily_collection_element.balance_amount
        );

        //console.log("dailyLoan req.body ------->", dailyLoan);

        dailyLoan.balance_amount =
        daily_collection_element.balance_amount -
          dailyLoan.due_paying_amount;

        dailyLoan.total_paid_amount =
          daily_collection_element.total_paid_amount +
          dailyLoan.due_paying_amount;

        dailyLoan.to_be_collect =
          dailyLoan.due_paying_amount + daily_collection_element.to_be_collect;

        const savedData = await dailyLoan.save();

        dailyArr.push(savedData);
      }
    }
    res.status(200).json({
      success: true,
      message: constants.messages.general.create_success,
      data: dailyArr,
    });
  } catch (error) {
    res.status(422).json({
      success: false,
      message: constants.messages.general.validation_error,
      data: {
        error: error,
      },
    });
  }
};

exports.getMonthlyCollections = async function (req, res, next) {
  try {
    var data = await dbModel.monthly_collection.find(
      {
        loan_id: req.body.loan_id,
      },
      {
        _id: 0,
        date: 1,
        month: 1,
        interest_amount: 1,
        capital: 1,
        paid_amount: 1,
        balance: 1,
        collected_by: 1,
      }
    );
    res.json({ data: data });
  } catch (error) {
    res.json({
      message: constants.messages.general.error,
      error: error,
    });
  }
};

exports.addMonthlyCollection = async function (req, res, next) {
  try {
    const loan = await dbModel.loan.findOne(
      {
        _id: req.body.loan_id,
      },
      {
        _id: 0,
        amount: 1,
      }
    );

    const monthly = await dbModel.monthly_collection
      .findOne(
        {
          loan_id: req.body.loan_id,
        },
        {
          _id: 0,
          month: 1,
          capital: 1,
          paid_amount: 1,
          interest_amount: 1,
          balance: 1,
        }
      )
      .sort({
        $natural: -1,
      });

    var monthArr = [];

    if (monthly == null) {
      const monthlyLoan = new dbModel.monthly_collection(req.body);

      monthlyLoan.paid_amount = monthlyLoan.capital;

      monthlyLoan.balance = loan.amount - monthlyLoan.capital;

      monthlyLoan.interest_amount = loan.amount * process.env.MONTHLY_INTEREST;

      const savedData = await monthlyLoan.save();

      monthArr.push(savedData);
    } else {
      const monthlyLoan = new dbModel.monthly_collection(req.body);

      monthlyLoan.paid_amount = monthlyLoan.capital + monthly.paid_amount;

      monthlyLoan.balance = monthly.balance - monthlyLoan.capital;

      monthlyLoan.interest_amount =
        monthlyLoan.balance * process.env.MONTHLY_INTEREST;

      const savedData = await monthlyLoan.save();

      monthArr.push(savedData);
    }

    res.status(200).json({
      success: true,
      message: constants.messages.general.create_success,
      data: monthArr,
    });
  } catch (error) {
    res.status(422).json({
      success: false,
      message: constants.messages.general.validation_error,
      data: {
        error: error,
      },
    });
  }
};

exports.getMonthlyLoanLedger = async function (req, res, next) {
  try {
    var arr = [];
    const customer = await dbModel.customer.find(
      {},
      {
        _id: 1,
        customer_name: 1,
        customer_id: 1,
      }
    );

    // console.log("customer ------ >", customer)

    const loan = await dbModel.loan.find(
      {
        loan_type: req.body.loan_type,
      },
      {
        cust_id: 1,
        loan_date: 1,
        amount: 1,
        loan_no: 1,
        loan_type: 1,
        interest: 1,
      }
    );
    // console.log("loan ------ >", loan)

    const monthly_loan = await dbModel.monthly_collection.find(
      {},
      {
        loan_id: 1,
        balance: 1,
      }
    ).sort({_id:-1})

    for (let index = 0; index < loan.length; index++) {
      var loan_element = loan[index];

      var foundCustomer = _.findWhere(customer, {
        id: loan_element.cust_id,
      });

      var foundLoan = _.findWhere(monthly_loan, {
        loan_id: loan_element.id,
      });

      if (foundLoan == undefined) {
        var outputObject = {
          loan_date: loan_element.loan_date,
          loan_no: loan_element.loan_no,
          customer_name: foundCustomer.customer_name,
          amount: loan_element.amount,
          interest: loan_element.interest,
          balance: loan_element.amount,
        };
        arr.push(outputObject);
      } else {
        var outputObject = {
          loan_date: loan_element.loan_date,
          loan_no: loan_element.loan_no,
          customer_name: foundCustomer.customer_name,
          amount: loan_element.amount,
          interest: loan_element.interest,
          balance: foundLoan.balance,
        };
        arr.push(outputObject);
      }
    }

    res.send(arr);
  } catch (error) {
    console.log(error.message);
  }
};


exports.getDailyLoanLedger = async function (req, res, next) {
  try {
    var arr = [];
    const customer = await dbModel.customer.find(
      {},
      {
        _id: 1,
        customer_name: 1,
        customer_id: 1,
      }
    );

    // console.log("customer ------ >", customer)

    const loan = await dbModel.loan.find(
      {
        loan_type: req.body.loan_type,
      },
      {
        cust_id: 1,
        loan_date: 1,
        amount: 1,
        loan_no: 1,
        loan_type: 1,
        interest: 1,
        duration: 1
      }
    );
    // console.log("loan ------ >", loan)

    const daily_collection = await dbModel.daily_collection.find(
      {},
      {
        loan_id: 1,
        balance_amount: 1,
      }
    ).sort({_id:-1})

      // console.log("daily_collection ------ >", daily_collection)


    for (let index = 0; index < loan.length; index++) {
      const loan_element = loan[index];

      // console.log("loan_element -------->",loan_element)

      var foundCustomer = _.findWhere(customer, {
        id: loan_element.cust_id,
      });

      var foundLoan = _.findWhere(daily_collection, {
        loan_id: loan_element.id,
      });

      // console.log("foundCustomer -------->",foundCustomer)

      // console.log("foundLoan -------->",foundLoan)

      if (foundLoan == undefined) {
        var outputObject = {
          loan_id: loan_element._id,
          loan_date: loan_element.loan_date,
          loan_no: loan_element.loan_no,
          customer_name: foundCustomer.customer_name,
          amount: loan_element.amount,
          interest: loan_element.interest,
          balance: loan_element.amount,
          total_days: loan_element.duration,
        };
        arr.push(outputObject);
      } else {
        var outputObject = {
          loan_id: loan_element._id,
          loan_date: loan_element.loan_date,
          loan_no: loan_element.loan_no,
          customer_name: foundCustomer.customer_name,
          amount: loan_element.amount,
          interest: loan_element.interest,
          balance: foundLoan.balance_amount,
          total_days: loan_element.duration,
        };
        arr.push(outputObject);
      }
    }

    res.send(arr);
  } catch (error) {
    console.log(error.message);
  }
};