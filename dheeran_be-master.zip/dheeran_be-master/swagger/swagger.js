const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const createError = require("http-errors");
const express = require("express");
const router = express.Router();

exports.docs = async function (req, res) {
  try {
    // res.sendFile('api-docs/index.html');
    console.log(__dirname);
    // res.sendFile('index.html', { root: __dirname });
    res.sendFile(__dirname + "/api-docs/index.html");
  } catch (error) {
    console.log(error);
    res.json(error);
  }
};

exports.swagger = async function (req, res) {
  try {
    // res.sendFile('api-docs/index.html');
    console.log(__dirname);
    // res.sendFile('index.html', { root: __dirname });
    res.sendFile(__dirname + "/api-docs/swagger.json");
  } catch (error) {
    console.log(error);
    res.json(error);
  }
};
