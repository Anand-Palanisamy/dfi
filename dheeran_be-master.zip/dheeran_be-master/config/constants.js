var express = require("express");
var env = require("dotenv").config();

var messages = require("./messages");

var db;
// if (process.env.ENV == "LIVE") {
//     db = "mongodb://username:pass@domain.com:27017/SA?authSource=admin";
// } else {
//     db = "mongodb://localhost:27017/DHEERAN";
// }
db = process.env.MONGODB_URI + process.env.DB_NAME;

var app = {
  name: "Dheeran Finance",
};

var messages = messages;

getTxt = function () {
  var text = {
    JWT_SECRET: "tsrq",
    COOKIE_SECRET: ["zyxw tsrq"],
  };
  return text;
};

var server_status = {
  success: 200,
  error: 500,
  invalid: 400,
  does_not_exist: 404,
  validation_error: 422,
};

var constants = {};
constants.app = app;
constants.messages = messages;
constants.db = db;
constants.getTxt = getTxt;
module.exports = constants;
