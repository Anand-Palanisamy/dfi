var general = {
  fetch_success: "Fetched Success",
  update: "Update Success",
  create_success: "Created Success",
  cust_not_created: "Customer Details not created",
  loan_not_created: "Loan Details not created",
  update_success: "Update Success",
  delete_success: "Deleted Success",
  validation_error: "ValidationError",
  error: "Something went wrong",
  no_data: "Data not found",
  server_error: "Server Error",
  invalid_landing: "Invalid Landing",
  server_up: "Server is up and running",
  invalid: "Invalid Id",
  does_not_exist: "Data does not exist",
  duplicate_key_error: "duplicate key error"
};

var server_status = {
  success: 200,
  error: 500,
  invalid: 400,
  does_not_exist: 404,
};

var messages = {};

messages.general = general;
messages.server_status = server_status;
module.exports = messages;
